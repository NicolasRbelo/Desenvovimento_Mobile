package com.example.app_duo

class ConteudoTextos {
}