package com.example.app_duo

class CoteudoFormas {
}